
from __future__ import unicode_literals, print_function, division
from io import open
import unicodedata
import string
import re
import random
import time
from nltk.translate import bleu_score

import torch
import torch.nn as nn
from torch import optim
import torch.nn.functional as F

from torch.utils.data import Dataset
from torch.utils.data import DataLoader

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import math
from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.bleu_score import SmoothingFunction

SOS_token = 0
EOS_token = 1
MAX_LENGTH = 100

class Lang():
    def __init__(self, corpus, device, target_lang=False):
        self.corpus = corpus
        self.SOS_TOKEN = 0
        self.EOS_TOKEN = 1
        self.target_lang = target_lang
        print("Loading sentences for corpus {corpus}".format(corpus=corpus))
        self.sentences = self.load_sentences(corpus)
        print("Loading dictionary for corpus {corpus}".format(corpus=corpus))
        (self.idx2word, self.word2idx) = self.load_dictionary(corpus)
        print("Converting sentences to tensors for corpus {corpus}".format(corpus=self.corpus))
        self.sentence_tensors = self.tensorize_sentences(self.sentences)
        
    def tensorize_sentences(self, sentences):
        return [self.tensorFromSentence(sentence) for sentence in self.sentences]            
        
    def load_sentences(self, corpus):   
        corpus_file_as_list = open(corpus, 'r').readlines()
        sentences = [self.normalize_token(sentence) for sentence in corpus_file_as_list]
        # sentences = [sentence for sentence in sentences if sentence != ""]
        return sentences
    
    def load_dictionary(self, corpus):
        corpus_file_as_blob = open(self.corpus, 'r').read().split()
        tokens = [self.normalize_token(token) for token in corpus_file_as_blob]
        filtered_tokens = set(tokens)
        idx2word = {k+2: v for k, v in enumerate(filtered_tokens)}
        idx2word[self.SOS_TOKEN] = 'SOS'
        idx2word[self.EOS_TOKEN] = 'EOS'
        word2idx = {k: v for v, k in idx2word.items()}
        return (idx2word, word2idx)
    
    def unicode_to_ascii(self, s):
        return ''.join(
            c for c in unicodedata.normalize('NFD', s)
            if unicodedata.category(c) != 'Mn'
        )

    def normalize_token(self, s):
        return self.normalize_string(s)
    
    def normalize_string(self, s, punctuation_replacement=None):
        s = self.unicode_to_ascii(s.lower().strip())
        s = re.sub(r"[^a-zA-Z.!?\d ]", r"" if punctuation_replacement==None else punctuation_replacement, s)
        return s

    def indexesFromSentence(self, sentence):
        vec = [self.word2idx[word] for word in sentence.split(' ') if (word != '' and word !=' ')]
        if(self.target_lang):
            vec.insert(0, self.SOS_TOKEN)
        return vec

    def tensorFromSentence(self, sentence):
        indexes = self.indexesFromSentence(sentence)
        indexes.append(self.EOS_TOKEN)
        return torch.tensor(indexes, dtype=torch.long, device=device).view(-1, 1)

class EncoderRNN(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(EncoderRNN, self).__init__()
        self.hidden_size = hidden_size

        self.embedding = nn.Embedding(input_size, hidden_size)
        self.gru = nn.GRU(hidden_size, hidden_size, bidirectional=True)

    def forward(self, input, hidden):
        embedded = self.embedding(input).view(1, 1, -1)
        output = embedded
        output, hidden = self.gru(output, hidden)
        return output, hidden

    def initHidden(self):
        return torch.zeros(2, 1, self.hidden_size, device=device)
    
class AttnDecoderRNN(nn.Module):
    def __init__(self, hidden_size, output_size, dropout_p=0.1, max_length=MAX_LENGTH):
        super(AttnDecoderRNN, self).__init__()
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.dropout_p = dropout_p
        self.max_length = max_length
        self.bidir_factor = 2

        self.embedding = nn.Embedding(self.output_size, self.hidden_size*self.bidir_factor) #BIDIR 
        self.attn = nn.Linear(self.hidden_size * 2*self.bidir_factor, self.max_length) #BIDIR 
        self.attn_combine = nn.Linear(self.hidden_size * 2 * self.bidir_factor, self.hidden_size * self.bidir_factor)
        self.dropout = nn.Dropout(self.dropout_p)
        self.gru = nn.GRU(self.hidden_size*2, self.hidden_size, bidirectional=True)
        self.out = nn.Linear(self.hidden_size*2, self.output_size)

    def forward(self, input, hidden, encoder_outputs):
        embedded = self.embedding(input).view(1, 1, -1)
        embedded = self.dropout(embedded)
        attn_weights = F.softmax(
            self.attn(torch.cat((embedded[0], hidden.flatten().unsqueeze(0)), 1)), dim=1)
        attn_applied = torch.bmm(attn_weights.unsqueeze(0),
                                    encoder_outputs.unsqueeze(0))

        output = torch.cat((embedded[0], attn_applied[0]), 1)
        output = self.attn_combine(output).unsqueeze(0)

        output = F.relu(output)
        output, hidden = self.gru(output, hidden)

        output = F.log_softmax(self.out(output[0]), dim=1)
        return output, hidden, attn_weights

    def initHidden(self):
        return torch.zeros(1, 1, self.hidden_size, device=device)


teacher_forcing_ratio = 0.5

def train(input_tensor, target_tensor, encoder, decoder, encoder_optimizer, decoder_optimizer, criterion, max_length=MAX_LENGTH):
    encoder_hidden = encoder.initHidden()
    encoder.train()
    decoder.train()

    encoder_optimizer.zero_grad()
    decoder_optimizer.zero_grad()

    input_tensor = input_tensor.squeeze()
    target_tensor = target_tensor.squeeze()

    try:
        input_length = input_tensor.size(0)
    except:
        input_tensor = input_tensor.unsqueeze(0)
        input_length = input_tensor.size(0)

    try:
        target_length = target_tensor.size(0)
    except:
        target_tensor = target_tensor.unsqueeze(0)
        target_length = target_tensor.size(0)
            

    encoder_outputs = torch.zeros(max_length, encoder.hidden_size*2, device=device)

    loss = 0

    for ei in range(input_length if input_length < max_length else max_length):
        encoder_output, encoder_hidden = encoder(
            input_tensor[ei], encoder_hidden)
        encoder_outputs[ei] = encoder_output[0, 0]

    decoder_input = torch.tensor([[SOS_token]], device=device)

    decoder_hidden = encoder_hidden

    use_teacher_forcing = True if random.random() < teacher_forcing_ratio else False

    if use_teacher_forcing:
        # Teacher forcing: Feed the target as the next input
        for di in range(1, target_length):
            decoder_output, decoder_hidden, decoder_attention = decoder(
                decoder_input, decoder_hidden, encoder_outputs)
            expected_token = torch.unsqueeze(target_tensor[di], 0)
            loss += criterion(decoder_output, expected_token)
            decoder_input = target_tensor[di]  # Teacher forcing

    else:
        # Without teacher forcing: use its own predictions as the next input
        for di in range(target_length):
            decoder_output, decoder_hidden, decoder_attention = decoder(
                decoder_input, decoder_hidden, encoder_outputs)
            topv, topi = decoder_output.topk(1)
            decoder_input = topi.squeeze().detach()  # detach from history as input
            expected_token = torch.unsqueeze(target_tensor[di], 0)
            loss += criterion(decoder_output, expected_token)
            if decoder_input.item() == EOS_token:
                break

    loss.backward()

    encoder_optimizer.step()
    decoder_optimizer.step()

    return loss.item() / target_length


def asMinutes(s):
    m = math.floor(s / 60)
    s -= m * 60
    return '%dm %ds' % (m, s)

def timeSince(since, percent):
    now = time.time()
    s = now - since
    es = s / (percent)
    rs = es - s
    return '%s (- %s)' % (asMinutes(s), asMinutes(rs))

def evaluate(encoder, decoder, test_loader, evaluate_sample_size, output_lang, max_length=MAX_LENGTH):
    with torch.no_grad():
        encoder.eval()
        decoder.eval()
        score = 0
        for idx in range(0, evaluate_sample_size):
            (input_tensor, input_sentence, target_tensor, target_sentence) = iter(test_loader).next()
             
            input_tensor = input_tensor.squeeze()
            target_tensor = target_tensor.squeeze() 
            
            try:
                input_length = input_tensor.size(0)
            except:
                input_tensor = input_tensor.unsqueeze(0)
                input_length = input_tensor.size(0)

            try:
                target_length = target_tensor.size(0)
            except:
                target_tensor = target_tensor.unsqueeze(0)
                target_length = target_tensor.size(0)

            encoder_hidden = encoder.initHidden()

            encoder_outputs = torch.zeros(max_length, encoder.hidden_size*2, device=device)

            for ei in range(input_length):
                encoder_output, encoder_hidden = encoder(input_tensor[ei],
                                                            encoder_hidden)
                encoder_outputs[ei] += encoder_output[0, 0]

            decoder_input = torch.tensor([[SOS_token]], device=device)  # SOS

            decoder_hidden = encoder_hidden

            decoded_words = []
            decoder_attentions = torch.zeros(max_length, max_length)

            for di in range(max_length):
                decoder_output, decoder_hidden, decoder_attention = decoder(
                    decoder_input, decoder_hidden, encoder_outputs)
                decoder_attentions[di] = decoder_attention.data
                topv, topi = decoder_output.data.topk(1)
                if topi.item() == EOS_token:
                    decoded_words.append('<EOS>')
                    break
                else:
                    decoded_words.append(output_lang.idx2word[topi.item()])

                decoder_input = topi.squeeze().detach()
                
            score = score + bleu_score.sentence_bleu(target_sentence, decoded_words, smoothing_function=SmoothingFunction().method1)

        return score/evaluate_sample_size*100

def trainIters(encoder, decoder, n_iters, train_loader, test_loader, output_lang, print_every=100, test_every=500, learning_rate=0.01):
    start = time.time()
    plot_losses = []
    print_loss_total = 0  # Reset every print_every
    plot_loss_total = 0  # Reset every plot_every

    encoder_optimizer = optim.SGD(encoder.parameters(), lr=learning_rate)
    decoder_optimizer = optim.SGD(decoder.parameters(), lr=learning_rate)
    criterion = nn.NLLLoss()

    for idx in range(1, n_iters + 1):
        (input_tensor, input_sentence, target_tensor, output_sentence) = iter(train_loader).next()

        loss = train(input_tensor, target_tensor, encoder,
                        decoder, encoder_optimizer, decoder_optimizer, criterion)
        print_loss_total += loss
        plot_loss_total += loss

        if idx % print_every == 0:
            print_loss_avg = print_loss_total / print_every
            print_loss_total = 0
            print('%s (%d %d%%) %.4f' % (timeSince(start, idx / n_iters),
                                            idx, idx / n_iters * 100, print_loss_avg))
        if idx % test_every == 0:
            print('%s (%d %d%%) BLUE:%.4f' % (timeSince(start, idx / n_iters),
                                            idx, idx / n_iters * 100, evaluate(encoder, decoder, test_loader, 500, output_lang)))


class TranslationDataset(Dataset):
    def __init__(self, src_lang, dst_lang):
        self.src_lang_tensors = src_lang.sentence_tensors
        self.src_lang_sentences = src_lang.sentences
        self.dst_lang_tensors = dst_lang.sentence_tensors
        self.dst_lang_sentences = dst_lang.sentences
        if len(self.src_lang_tensors) != len(self.dst_lang_tensors):
            raise Exception("Mismatch between language datasets")
        self.dataset_len = len(self.src_lang_tensors)
    
    def __len__(self):
         return self.dataset_len
     
    def __getitem__(self, index):
        return (self.src_lang_tensors[index], self.src_lang_sentences[index], self.dst_lang_tensors[index], self.dst_lang_sentences[index])

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# device = "cpu"

en = Lang('./data/en-vi/train.en', device)
vi = Lang('./data/en-vi/train.vi', device, target_lang=True)

train_dataset = TranslationDataset(en, vi)

train_loader = DataLoader(train_dataset, shuffle=True)

print("Loading en test")
en_test = Lang('./data/en-vi/test.en', device)
print("Loading vi test")
vi_test = Lang('./data/en-vi/test.vi', device, target_lang=True)
test_dataset = TranslationDataset(en_test, vi_test)
test_loader = DataLoader(test_dataset, shuffle=True)

hidden_size = 256
encoder1 = EncoderRNN(len(en.word2idx), hidden_size).to(device)
attn_decoder1 = AttnDecoderRNN(hidden_size, len(vi.word2idx), dropout_p=0.1).to(device)

trainIters(encoder1, attn_decoder1, 75000, train_loader=train_loader, test_loader=test_loader, print_every=100, output_lang=vi)
